/* etInsertEvent.c
*
*  R. Michaels, Jan 2000
*  For inserting data into the ET system.
*  Inputs: 
*     evbuffer:  CODA data in standard format
*     et_filename:  The ET memory file, eg. /tmp/et_sys_$SESSION
*
*  Notes:
*     This code was based on the /examples/et_producer.c
*     code which I got from C. Timmer in Jan 2000.
*
*/
   
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "et.h"
#include <et_private.h>

/* HARDMAX kluge: if event_size too big, we truncate.  This is ugly,
   but hopefully temporary.  It is a problem on Linux, not SunOS.
   This parameter must be less than the '-s' parameter in et_start */

#define HARDMAX 17500

#define OK 0
#define ERROR -1
#define DEBUG 1  /* if 1, print some debug statements */


/*********** ET Variables ************/
#define ET_EVENT_ARRAY_SIZE_MAX  6  /* number of ET events to ask for */
static et_event		*etevents[ET_EVENT_ARRAY_SIZE_MAX];
extern char		et_name[ET_FILENAME_LENGTH];
extern char		et_host[MAXHOSTNAMELEN];
extern int              et_port;
extern int              et_group;

static et_sys_id	et_sys;
static et_att_id	et_attach;
static size_t		et_eventsize;
static int		et_init = 0, et_reinit = 0;



/*********** ET Initialization ************/
static int et_initialize(void) {
  et_openconfig   openconfig;
  struct timespec timeout;
  int status=0;
  int sendbufsize = TOTAL_SEND_BUF_SIZE;

  /* Set connection timeout */
  timeout.tv_sec  = 10;
  timeout.tv_nsec = 0;

  /* Normally, initialization is done only once. However, if the ET
   * system dies and is restarted, and we're running remotely or on
   * a Linux operating system, then we need to re-initalize in
   * order to reestablish the tcp connection for communication etc.
   */
  if (et_init > 0) {
    /* unmap shared mem, detach attachment, close socket, free et_sys */
    et_forcedclose(et_sys);
  }

  if (et_open_config_init(&openconfig) != ET_OK) {
    printf("ERROR: ET init: cannot allocate memory to open ET system\n");
    return ERROR;
  }
  et_open_config_setwait(openconfig, ET_OPEN_WAIT);
  et_open_config_settimeout(openconfig, timeout);

  /* Check for connect mode Direct or Multicast */
  if(strcmp(et_host,"239.200.0.0") == 0) {

    /* always connect as if the ROC is remote */
    et_open_config_sethost(openconfig,ET_HOST_ANYWHERE);
    et_open_config_setmode(openconfig,ET_HOST_AS_REMOTE);

    et_open_config_setcast(openconfig,ET_MULTICAST);
    et_open_config_addmulticast(openconfig,et_host);
    et_open_config_setport(openconfig,et_port);
    et_open_config_setTTL(openconfig,16);

  }else{
    printf("Connecting to ET on host %s and port %d\n",et_host,et_port);
    et_open_config_sethost(openconfig,et_host);
    et_open_config_setcast(openconfig,ET_DIRECT);
    et_open_config_setserverport(openconfig,et_port);
  }


  /* Sometimes we see a problem with ROCs failing to connect to a remote ET system
     when there are many ROCs attempting to connect at the same time (at Prestart).
     So if the et_init fails we will try one additional time to see if it can connect
     on the second attempt  */
  if (et_open(&et_sys, et_name, openconfig) != ET_OK) {
    printf(" **Failure to connect to ET - Will try one more time...\n");
    if (et_open(&et_sys, et_name, openconfig) != ET_OK) {
      printf ("ERROR: ET init: cannot open ET system (%s)",et_name);
      return ERROR;
    }
  }

  /* Dump the config structure - We do not need it anymore */
  et_open_config_destroy(openconfig);

  /* Set level of debug output */
  et_system_setdebug(et_sys, ET_DEBUG_ERROR);

  if ((status=et_station_attach(et_sys, ET_GRANDCENTRAL, &et_attach)) < 0) {
    et_close(et_sys);
    printf ("ERROR: ET init: cannot attach to ET station status=%d",status);
    return ERROR;
  }

  /* Find out the max event size in this ET system */
  if (et_system_geteventsize(et_sys, &et_eventsize) != ET_OK) {
    et_close(et_sys);
    printf ("ERROR: ET init: cannot determine event size in ET system");
    return ERROR;
  }

  /* Check if et_system is setup for large buffers */
  if(et_eventsize < sendbufsize) {
    et_close(et_sys);
    printf ("ERROR: ET init: ET system event size (%d bytes) is smaller than ROC output buffers (%d bytes)",
	      et_eventsize, sendbufsize);
    return ERROR;
  }else{
    printf("INFO: ET init: ET Buffer size = %d bytes - OK (>Max Record size: %d bytes)\n",et_eventsize, sendbufsize);
  }


  et_init++;
  et_reinit = 0;
  printf("INFO: ET_INIT: ET fully initialized");
  return OK;
}



int etInsertEvent(int evbuffer[], char* et_filename)
{  
  int        i, j, status, nevents_max;
  et_att_id  attach;
  et_sys_id  id;
  et_event   *pe;
  et_openconfig openconfig;
  int    len, event_size;   
  char   *pdata;
  int    try;

  len = evbuffer[0]+1;
  event_size = len*sizeof(long);
  if (event_size > HARDMAX) {
    printf("etInsertEvent: WARNING: truncating an inserted event\n");
    printf("event size = %d exceeds maximum = %d\n",event_size,HARDMAX);
    printf("This warning is only for file insertions and is not fatal\n");
    event_size = HARDMAX;  /* see comment above  !! */
  }

  if(DEBUG) printf("in etInsertEvent, event length %d   et_filename %s \n",event_size,et_filename);
  
  /* opening the ET system is the first thing we must do */
  try = 1;
  et_open_config_init(&openconfig);
  if(DEBUG) printf("open config init\n");
tryloop:
  status = et_open(&id, et_filename, openconfig);
  if (status != ET_OK) {
    printf("etInsertEvent: et_open status = %d attempt %d\n",status,try);
    if (try < 2) {
        sleep(2);
        try = try+1;
        goto tryloop;
    }
    printf("etInsertEvent: ERROR: et_open failed\n");
    return ERROR;
  }
  if(try > 1) printf("Ok... succeeded after a 2nd try...\n");
  et_open_config_destroy(openconfig);

  if(DEBUG) printf("et_open ok\n");
  
  /* set the level of debug output that we want (everything or nothing */
  if(DEBUG) { 
      et_system_setdebug(id, ET_DEBUG_INFO);
  } else {
      et_system_setdebug(id, ET_DEBUG_NONE);
  }   

  /* attach to GRANDCENTRAL station since we are producing events */
  if (et_station_attach(id, ET_GRANDCENTRAL, &attach) < 0) {
    printf("etInsertEvent: error in station attach\n");
    return ERROR;
  }

  if( !et_alive(id)) {
    printf("ERROR: ET is not alive\n");
    return ERROR;
  }

  if(DEBUG) printf("et alive\n");

  /* get new/unused event */  
  status = et_event_new(id, attach, &pe, ET_SLEEP, NULL, event_size);
  if (status != ET_OK) {
     printf("etInsertEvent: error in et_event_new\n");
     return ERROR;
  }

  if(DEBUG) printf("et got event new\n");  
  
  /* put data into the event here */  
  
  et_event_getdata(pe, (void **)&pdata);
  et_event_setlength(pe, event_size);

  memcpy((void*)pdata, (const void *)evbuffer, event_size);

  if(DEBUG) printf("getdata, setlength, memcpy ok\n");

  /* put event back into the ET system */
  status = et_event_put(id, attach, pe);
  if (status != ET_OK) {
     printf("etInsertEvent: put error\n");
     return ERROR;
  }
  
  if (et_station_detach(id, attach) != ET_OK) {
    printf("etInsertEvent: ERROR: et_station_detach\n");
  }
  if (et_close(id) != ET_OK) {
    printf("etInsertEvent: ERROR: et_close\n");
  }

  if(DEBUG) printf("etInsertEvent finished successfully\n");

  return OK;

}





